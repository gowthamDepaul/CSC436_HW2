import { Messages } from './messages.model';

describe('Messages.Model', () => {
  it('should create an instance', () => {
    expect(new Messages()).toBeTruthy();
  });
});
