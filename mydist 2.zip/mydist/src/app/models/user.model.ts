export class User {
   
    name:string;
    constructor(public nameInput: string) {
        this.name = nameInput;
    }
}
